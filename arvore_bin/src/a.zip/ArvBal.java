/* "jogar fora" a árvore e re-inserir tudo denovo para balancear */

public class ArvBal extends ArvBin {

    public ArvBal(int len) {
        super(len);
    }
}
