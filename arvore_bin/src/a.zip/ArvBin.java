/*
* alguns dos nomes de variáveis e de funções foram definidos especificamente no exercício, então talvez fique meio sem sentido pensando aos nomes que eu dou pras coisas
*/

public class ArvBin {
    private String[] heap;
    private int len, quant; // len == tamanho máximo da heap. quant == posições ocupadas da heap

    public ArvBin(int len) {
        this.len = len;
        heap = new String[len];
        quant = 0;
        for (int i = 0; i < len; i++)
            heap[i] = "";
    }


    public boolean find(String v) {
        return (buscaBin(v) != -1);
    }


    private int buscaBin(String busca) {
        int esq = 0;
        int dir = quant - 1;

        while (esq <= dir) {
            int meio = esq + (dir - esq) / 2;
            int compara = busca.compareTo(heap[meio]); // strcmp do java

            if (compara == 0)
                return meio; // encontrou
            else if (compara < 0)
                dir = meio - 1; // ta mais pra tras no array
            else
                esq = meio + 1; // ta mais pra frente no array

        }
        return -1; // caso não achou
    }


    public int len() {
        // comicamente, apesar do nome da função, retorno aqui quantos elementos tem na heap (que é "quant", e nao "len")
        return quant;
    }


    public void insert(String v) {
        if (quant == len) { // quando o número de elementos (quant) for igual à capacidade (len), lotou a heap
            System.out.println("capacidade máxima alcançada!");
            return;
        }

        if(!insertAux(0, v)) {
            System.out.println("inserção falhou");
            return;
        }
        quant++;
    }

    // auxiliar para inserção. sempre insere de forma que mantém a ordenação da árvore
    private boolean insertAux(int index, String v) {
        if (index >= len) return false;

        if (heap[index].isEmpty()) {
            heap[index] = v;
            return true;
        }

        if (v.compareTo(heap[index]) < 0)
            return insertAux(filhoEsq(index), v);
        else
            return insertAux(filhoDir(index), v);

    }


    private int filhoEsq(int index) {
        return 2 * index + 1;
    }


    private int filhoDir(int index) {
        return 2 * index + 2;
    }

    private boolean indiceValido(int index) {
        return (index >= 0 && index < len && !heap[index].isEmpty());
    }


    public boolean remove(String v) {
        int index = buscaBin(v);
        if (index == -1) return false;

        removeAux(index);
        return true;
    }

    private void removeAux(int index) {
        // caso o nó a ser removido seja uma folha
        if (!indiceValido(filhoEsq(index)) && !indiceValido(filhoDir(index)))
            heap[index] = ""; // apenas remove, nao reposiciona nada

        // caso tenha apenas filho esquerdo
        else if (indiceValido(filhoEsq(index)) && indiceValido(filhoDir(index)))
            promoveSubarvore(filhoEsq(index), index); // promove o filho à esquerda como raiz da subárvore

        // caso tenha apenas filho direito
        else if (!indiceValido(filhoEsq(index)) && indiceValido(filhoDir(index)))
            promoveSubarvore(filhoDir(index), index); // promove o filho à direita como raiz da subárvore

        // caso tenha os dois filhos
        else {
            int menorDir = achaMenor(filhoDir(index)); // pega o menor filho à direita
            heap[index] = heap[menorDir]; // substitui como pai dos demais abaixo (e remove o pai atual)
            removeAux(menorDir); // remove o nó movido
        }

        quant--;

    }

    private int achaMenor(int index) {
        while (indiceValido(filhoEsq(index))) {
            index = filhoEsq(index);
        }
        return index;
    }


    private void promoveSubarvore(int indexPai, int indexFilho) {
        heap[indexPai] = heap[indexFilho];
        heap[indexFilho] = "";

        // posiciona os netos do pai sendo tratado
        if (indiceValido(filhoEsq(indexFilho)))
            promoveSubarvore(filhoEsq(indexFilho), filhoEsq(indexPai));
        if (indiceValido(filhoDir(indexFilho)))
            promoveSubarvore(filhoDir(indexFilho), filhoDir(indexPai));

    }


    private void swap(int i, int j) {
        String aux = heap[i];
        heap[i] = heap[j];
        heap[j] = aux;
    }


}
