/* fazer rotações para balancear */

public class ArvAVL extends ArvBin {

    public ArvAVL(int len) {
        super(len);
    }
}
