
public class Main {
    public static void main(String[] args) {
        ArvBin arvore = new ArvBin(10);
        arvore.insert("D");
        arvore.insert("B");
        arvore.insert("F");
        arvore.insert("A");
        arvore.insert("C");


    }
}
